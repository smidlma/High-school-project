<?php

$host = 'localhost';
$user = 'root';
$password = '';
$database = 'autoservis';
$conn = new mysqli($host, $user, $password, $database);
$conn->set_charset("utf8");
