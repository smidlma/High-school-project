<?php
    

		header("Location: Autoservis/login.php");
?>